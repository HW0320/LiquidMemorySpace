# 液态玻璃记忆空间 · Android 项目

这是把提供的 HTML 页面封装为 Android WebView 应用的项目源码。

## 已处理
- Android 启动入口与 WebView 容器。
- 支持从手机文件选择器上传照片、导入 JSON 备份。
- JSON 备份通过 Android 下载目录保存。
- 使用应用内 HTTPS 资源地址承载本地 HTML，让 WebView 的 IndexedDB 可用。
- 新增 IndexedDB 自动保存：记忆照片、随笔便签、标签、视觉设置、画布变换会在交互后自动保存；不可用时回退 localStorage。
- 保留原页面液态玻璃视觉、画布和 3D 暗房交互。

## 原生 Android 能力
- 已补齐 `MainActivity`、应用主题和 AndroidX WebKit AssetLoader。
- WebView 通过 HTTPS 本地资源域名加载页面，使 IndexedDB 在应用内可用。
- 原生文件选择器支持网页中的照片和 JSON 选择；JSON 备份通过系统“创建文件”界面保存。

## 云端编译（无需本机安装 Android SDK）
项目包含 `.github/workflows/android.yml`。将解压后的项目内容上传到一个 GitHub 仓库，在仓库的 **Actions** 页面运行 **Build Android APK** 工作流。成功后打开该次运行记录，在 **Artifacts** 下载 `LiquidMemorySpace-debug-apk`，解压即可得到 `app-debug.apk`。工作流使用 GitHub 托管的 Ubuntu 环境、JDK 17、Gradle 8.9 和 Android SDK。

## 重要说明
页面原始版本使用 Tailwind CDN 与 Three.js CDN，因此应用首次打开及 3D 暗房使用这些功能时需要网络连接。照片、便签和设置数据保存在本机 WebView 数据区，不会自动上传到云端。卸载应用或清除应用数据会清除本地保存，请定期使用设置里的 JSON 导出功能备份。

## 如何生成 APK
当前交付环境无法访问 Google Android SDK 下载站，因此不能在这里直接执行最终编译。可用 Android Studio 打开本文件夹：

1. 安装 Android Studio，并安装 Android SDK Platform 35。
2. 用 Android Studio 打开本项目根目录（包含 `settings.gradle` 的文件夹）。
3. 等待 Gradle 同步完成，然后选择 **Build → Build Bundle(s) / APK(s) → Build APK(s)**。
4. Debug APK 通常生成在 `app/build/outputs/apk/debug/app-debug.apk`。

也可在配置好 JDK、Android SDK 和 Gradle 的终端中执行 `./build_apk.sh`，或执行：

```bash
gradle assembleDebug
```

安装到手机：

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

## 应用信息
- 名称：液态玻璃记忆空间
- Application ID：`com.liquidmemory.space`
- 最低 Android：6.0（API 23）
- Target SDK：35
