# Memory Space Beta 0.5

## Changes
- Default timeline order is newest-to-oldest; selectable newest-to-oldest, oldest-to-newest, and title order.
- Date parsing accepts `YYYY.MM.DD`, `YYYY-MM-DD`, Chinese date strings, and ISO-compatible dates; undated entries remain at the end.
- Timeline ribbons are refreshed during card drag frames, not only after pointer release.
- Card drag uses pointer capture where supported to improve Android WebView pointer-up reliability.
- Touch controls remain visible and have larger hit targets on coarse-pointer devices.
- Reduced-motion preference is respected; canvas and SVG compositing receive conservative containment hints.

## Community research and reuse decision
- `c0di-org/Flow` (infinite canvas) informed interaction patterns such as touch pan/zoom, sticky notes, connectors, undo/redo. No source code copied.
- `DatanoiseTV/lumiere` informed the distinction between visual film presets and physically modelled film/chemistry. No source code copied.
- `Bloxmine/darkroom` informed non-destructive GPU node-graph photo effects. No source code copied.
- `OpenHome3D` and `architect3d` informed modular room composition and CC0 asset provenance. No model files copied.

External projects are not bundled. Their licenses and dependency trees were not imported, avoiding accidental license contamination. This build keeps the existing Three.js room implementation and focuses this iteration on timeline and touch reliability.

## Validation performed
- Inline JavaScript syntax: `node --check` passed.
- Android XML files: parsed with Python XML parser.
- ZIP integrity: tested with `unzip -t`.
- Not performed: Android SDK APK build, real-device touch testing, visual comparison of the 3D room, GPU/power measurements. Do not treat static checks as device QA.
