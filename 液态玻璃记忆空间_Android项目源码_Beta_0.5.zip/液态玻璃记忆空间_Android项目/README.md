# 液态玻璃记忆空间 · Android 项目 Beta 0.4

这是 Beta 0.4 的 Android WebView 项目源码，可通过 GitHub Actions 云端编译 APK。

## Beta 0.4 修复与升级
- 修复主页便签单击无法打开：单击便签直接进入编辑器，双击也可打开；照片卡片单击进入详情。
- 统一卡片拖动、缩放的全局指针管理，不再为每张卡片单独注册全局 move/up 监听，降低卡片数量增加时的事件开销。
- 拖动过程改为 requestAnimationFrame 合帧更新，松手后再更新时间线连线，减少移动端布局抖动。
- 触屏设备始终显示便签/照片快捷操作，不再依赖 hover。
- 照片延迟加载并异步解码，降低首次打开大量资料时的解码压力。
- 暗房新增「运行自检」面板：检查八种显影预设的渲染执行、相机视点、三槽药液、成片画布、JPG 导出、收入记忆空间、曝光/颗粒调节与自动显影。
- 保留 Beta 0.3 的 3D 暗房、显影配方、实时成片、导出和本地记忆数据。

## Android 原生能力
- Android WebView 容器、AndroidX WebKit AssetLoader。
- 手机文件选择器支持照片与 JSON 导入；JSON 备份通过系统创建文件界面保存。
- IndexedDB 本地保存记忆照片、便签、标签、视觉设置与画布状态；卸载应用或清除数据前请先导出 JSON 备份。

## 云端编译
1. 将项目 ZIP 上传到 GitHub 仓库（替换旧项目内容）。
2. 保留仓库根目录 `.github/workflows/android.yml`。
3. 在 Actions 成功记录的 Artifacts 中下载 `LiquidMemorySpace-debug-apk`，解压后安装 `app-debug.apk`。

## 验证说明
- 已执行内嵌 JavaScript 语法检查、Android XML 解析、HTML 控件处理函数静态核对与 ZIP 内容检查。
- 当前工作环境没有 Android SDK，未在此处直接编译 APK；请用 GitHub Actions 完成实际编译，并在目标手机上做触控验收。
- 页面依赖 Tailwind CSS CDN 与 Three.js CDN，首次加载及 3D 暗房需要网络连接。

## 应用信息
- Application ID：`com.liquidmemory.space`
- 版本：`0.4.0`（versionCode 4）
- 最低 Android：6.0（API 23）
- Target SDK：35

## Beta 0.5
See `README_Beta_0.5.md` for iteration notes, community research decisions, and validation limits.
